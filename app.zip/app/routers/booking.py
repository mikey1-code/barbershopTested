import os
from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import date
from app.database.deps import get_db
from app.schemas.booking import BookingCreate, BookingResponse, BookingWithUser
from app.crud.booking import (
    create_booking, get_booking, get_all_bookings_sorted,
    get_bookings_by_date, update_booking, delete_booking,
    get_all_bookings_with_users
)

router = APIRouter(prefix="/bookings", tags=["bookings"])

ADMIN_KEY = os.getenv("ADMIN_KEY")

# prosta ochrona panelu admina - klucz musi się zgadzać z ADMIN_KEY w .env
def verify_admin(x_admin_key: str = Header(default="")):
    if not ADMIN_KEY:
        raise HTTPException(status_code=500, detail="ADMIN_KEY nie jest ustawiony w .env")
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(status_code=401, detail="Nieprawidłowe hasło")
    return True

# WAŻNE: ta ścieżka musi być zdefiniowana PRZED "/{booking_id}",
# inaczej "admin" próbowałoby się dopasować jako booking_id (int) i by nie zadziałało.
@router.get("/admin/all", response_model=List[BookingWithUser])
def get_all_admin(db: Session = Depends(get_db), _: bool = Depends(verify_admin)):
    return get_all_bookings_with_users(db)

@router.get("/", response_model=List[BookingResponse])
def get_all(db: Session = Depends(get_db)):
    return get_all_bookings_sorted(db)

@router.get("/day/{target_date}", response_model=List[BookingResponse])
def get_by_date(target_date: date, db: Session = Depends(get_db)):
    return get_bookings_by_date(db, target_date)

@router.post("/", response_model=BookingResponse)
def create(booking: BookingCreate, db: Session = Depends(get_db)):
    return create_booking(db, booking)

@router.get("/{booking_id}", response_model=BookingResponse)
def get(booking_id: int, db: Session = Depends(get_db)):
    return get_booking(db, booking_id)

@router.put("/{booking_id}", response_model=BookingResponse)
def update(booking_id: int, new_data: BookingCreate, db: Session = Depends(get_db)):
    return update_booking(db, booking_id, new_data)

@router.delete("/{booking_id}")
def delete(booking_id: int, db: Session = Depends(get_db)):
    return delete_booking(db, booking_id)
