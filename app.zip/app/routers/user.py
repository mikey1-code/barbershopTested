from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.database.deps import get_db
from app.schemas.user import UserCreate, UserResponse
from app.crud.user import create_user, get_user, get_all_users, update_user, delete_user, get_user_by_email

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/", response_model=List[UserResponse])
def get_all(db: Session = Depends(get_db)):
    return get_all_users(db)

@router.post("/", response_model=UserResponse)
def create(user: UserCreate, db: Session = Depends(get_db)):
    existing_user = get_user_by_email(db, user.email)
    if existing_user:
        return existing_user  # 👈 email już istnieje - zwracamy istniejącego usera zamiast tworzyć nowego
    return create_user(db, user)

@router.get("/{user_id}", response_model=UserResponse)
def get(user_id: int, db: Session = Depends(get_db)):
    return get_user(db, user_id)

@router.put("/{user_id}", response_model=UserResponse)
def update(user_id: int, new_data: UserCreate, db: Session = Depends(get_db)):
    return update_user(db, user_id, new_data)

@router.delete("/{user_id}")
def delete(user_id: int, db: Session = Depends(get_db)):
    return delete_user(db, user_id)