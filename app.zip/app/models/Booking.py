from sqlalchemy import Column, Integer, String, Date, Time, ForeignKey
from sqlalchemy.orm import relationship
from app.database.base import base

class Booking(base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    time = Column(Time, nullable=False)
    service = Column(String, nullable=False)
    address = Column(String, nullable=True)
    notes = Column(String, nullable=True)

    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    user = relationship("User", back_populates="bookings")
