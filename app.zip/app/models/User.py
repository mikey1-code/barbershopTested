from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.database.base import base

class User(base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    surname = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    phone = Column(String)

    bookings = relationship("Booking", back_populates="user")