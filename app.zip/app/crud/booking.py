from sqlalchemy.orm import Session
from app.models.Booking import Booking
from app.schemas.booking import BookingCreate

def create_booking(db: Session, booking: BookingCreate):
    db_booking = Booking(**booking.model_dump())
    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    return db_booking

def get_booking(db: Session, booking_id: int):
    return db.query(Booking).filter(Booking.id == booking_id).first()

# custom function - get all bookings sorted by date then time
# UWAGA: filtrujemy rekordy z user_id IS NULL (np. stare/testowe wpisy) —
# inaczej BookingResponse (user_id: int) rzuca ResponseValidationError
# i CAŁY endpoint pada z błędem 500 przez jeden zepsuty rekord.
def get_all_bookings_sorted(db: Session):
    return db.query(Booking)\
              .filter(Booking.user_id.isnot(None))\
              .order_by(Booking.date.asc(), Booking.time.asc())\
              .all()

# custom function - get bookings for one specific day (useful for admin dashboard)
def get_bookings_by_date(db: Session, target_date):
    return db.query(Booking)\
              .filter(Booking.date == target_date, Booking.user_id.isnot(None))\
              .order_by(Booking.time.asc())\
              .all()

# custom function - pełne dane (razem z klientem) do panelu admina, chronione hasłem w routerze
def get_all_bookings_with_users(db: Session):
    return db.query(Booking)\
              .filter(Booking.user_id.isnot(None))\
              .order_by(Booking.date.asc(), Booking.time.asc())\
              .all()

def update_booking(db: Session, booking_id: int, new_data: BookingCreate):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    booking.date = new_data.date
    booking.time = new_data.time
    booking.service = new_data.service
    booking.user_id = new_data.user_id
    db.commit()
    db.refresh(booking)
    return booking

def delete_booking(db: Session, booking_id: int):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    db.delete(booking)
    db.commit()
