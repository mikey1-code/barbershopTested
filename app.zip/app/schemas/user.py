from pydantic import BaseModel
from typing import Optional, List
from app.schemas.booking import BookingResponse

class UserBase(BaseModel):
    name: str
    surname: str
    email: str
    phone: Optional[str] = None

class UserCreate(UserBase):
    pass

class UserResponse(UserBase):
    id: int
    bookings: List[BookingResponse] = []

    class Config:
        from_attributes = True