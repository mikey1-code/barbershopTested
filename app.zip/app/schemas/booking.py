from pydantic import BaseModel
from typing import Optional
from datetime import date, time

class BookingBase(BaseModel):
    date: date
    time: time
    service: str
    address: Optional[str] = None
    notes: Optional[str] = None
    user_id: int

class BookingCreate(BookingBase):
    pass

class BookingResponse(BookingBase):
    id: int

    class Config:
        from_attributes = True

# lekka wersja usera (bez zagnieżdżonych bookingów, żeby uniknąć rekurencji)
# używana tylko w panelu admina razem ze szczegółami rezerwacji
class BookingUserInfo(BaseModel):
    id: int
    name: str
    surname: str
    email: str
    phone: Optional[str] = None

    class Config:
        from_attributes = True

# pełne dane rezerwacji razem z danymi klienta - tylko do panelu admina
class BookingWithUser(BookingBase):
    id: int
    user: BookingUserInfo

    class Config:
        from_attributes = True
