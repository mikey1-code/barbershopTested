from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import user, booking
from app.database.base import base
from app.database.session import engine

base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(user.router)
app.include_router(booking.router)